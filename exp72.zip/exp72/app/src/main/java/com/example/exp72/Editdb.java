package com.example.exp72;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Editdb<MyDatabaseHelper> extends AppCompatActivity {

    private MyDatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editdb);

        MySQLiteOpenHelper dbHelper=new MySQLiteOpenHelper(this,"Book.db",null,1);

        Button createDatabase=(Button)findViewById(R.id.create_database);
        createDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dbHelper.getWritableDatabase();
                Log.d("Editdb", "database created ");
            }
        });

        Button addData=(Button)findViewById(R.id.insert_data);
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                ContentValues values=new ContentValues();
                values.put("name","Amy");
                values.put("number","364-789526");
                values.put("sex","female");
                db.insert("contacts",null,values);
                values.put("name","Sam");
                values.put("number","546-785133");
                values.put("sex","male");
                db.insert("contacts",null,values);
                values.clear();
                values.put("name","Tom");
                values.put("number","231-465697");
                values.put("sex","male");
                db.insert("contacts",null,values);
                Log.d("Editdb", "data inserted");

                //Toast.makeText(Editdb.this, "insert succeeded",Toast.LENGTH_SHORT).show();

            }
        });
    }
}